// server.js - Backend server for Research Paper Editor
// This handles API calls securely with your API key

const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = 3000;

// IMPORTANT: Replace with your actual Anthropic API key
const ANTHROPIC_API_KEY = 'AIzaSyCgsTxirq6pcEFBSTa1lbTG7Ka22nZfq2A';

app.use(cors());
app.use(express.json());

// Debug middleware to log all requests
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path} - Headers:`, req.headers.host);
    next();
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'Server is running' });
});

// NOTE: Static files will be served AFTER API routes, so API gets priority

// In-memory store for share sessions (with 24-hour expiry)
const shareSessions = {};
const SESSION_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

// In-memory store for timeline events
const timelineStore = {};
// In-memory store for notifications
const notificationStore = {};

// API endpoint to create a share session
app.post('/api/share/create', (req, res) => {
    try {
        console.log('[/api/share/create] Received request');
        console.log('[/api/share/create] Request body:', req.body);
        
        const { section, groups } = req.body;
        
        if (!section || !groups) {
            console.error('[/api/share/create] Missing section or groups');
            return res.status(400).json({ error: 'Section and groups are required' });
        }

        // Create session ID
        const sessionId = 'share_' + Date.now();
        
        // Store session data with expiry time
        shareSessions[sessionId] = {
            section: section,
            groups: groups,
            createdAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + SESSION_EXPIRY_MS).toISOString()
        };

        console.log(`✅ Share session created: ${sessionId}`);
        console.log('[/api/share/create] Sending response:', { success: true, sessionId });
        
        res.setHeader('Content-Type', 'application/json');
        res.json({ success: true, sessionId });
    } catch (error) {
        console.error('[/api/share/create] Error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// API endpoint to retrieve share session data
app.get('/api/share/:sessionId', (req, res) => {
    try {
        const { sessionId } = req.params;
        const session = shareSessions[sessionId];

        if (!session) {
            return res.status(404).json({ error: 'Share session not found or expired' });
        }

        // Check if session has expired
        if (new Date(session.expiresAt) < new Date()) {
            delete shareSessions[sessionId];
            return res.status(404).json({ error: 'Share session has expired' });
        }

        res.json({ success: true, data: { section: session.section, groups: session.groups } });
    } catch (error) {
        console.error('Share retrieval error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Cleanup expired sessions every hour
setInterval(() => {
    const now = new Date();
    let cleaned = 0;
    for (const sessionId in shareSessions) {
        if (new Date(shareSessions[sessionId].expiresAt) < now) {
            delete shareSessions[sessionId];
            cleaned++;
        }
    }
    if (cleaned > 0) {
        console.log(`🧹 Cleaned up ${cleaned} expired share sessions`);
    }
}, 60 * 60 * 1000);


// ============ TIMELINE MANAGEMENT ENDPOINTS ============

// GET all timeline events
app.get('/api/timeline', (req, res) => {
    try {
        const events = timelineStore.events || [];
        res.json({ 
            success: true, 
            events: events,
            lastUpdated: timelineStore.lastUpdated || null
        });
    } catch (error) {
        console.error('Timeline fetch error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// POST a new timeline event (adviser only)
app.post('/api/timeline', (req, res) => {
    try {
        const { title, date, adviser_id } = req.body;
        
        if (!title || !date) {
            return res.status(400).json({ error: 'Title and date are required' });
        }

        // Initialize timeline store if needed
        if (!timelineStore.events) {
            timelineStore.events = [];
        }

        const event = {
            id: 'event_' + Date.now(),
            title,
            date,
            adviser_id: adviser_id || 'default-adviser',
            createdAt: new Date().toISOString()
        };

        timelineStore.events.push(event);
        timelineStore.lastUpdated = new Date().toISOString();

        // Create notification for students and leaders
        if (!notificationStore.notifications) {
            notificationStore.notifications = [];
        }

        const notification = {
            id: 'notif_' + Date.now(),
            type: 'timeline_update',
            title: 'New Timeline Event',
            message: `New event added: "${title}" on ${date}`,
            event_id: event.id,
            read: false,
            createdAt: new Date().toISOString(),
            for_roles: ['student', 'student-leader'] // Notify both roles
        };

        notificationStore.notifications.push(notification);

        console.log(`✅ Timeline event created: ${event.id} - "${title}"`);
        console.log(`📢 Notification created for students and leaders`);

        res.json({ 
            success: true, 
            event: event,
            notification: notification
        });
    } catch (error) {
        console.error('Timeline save error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// DELETE a timeline event
app.delete('/api/timeline/:event_id', (req, res) => {
    try {
        const { event_id } = req.params;
        
        if (!timelineStore.events) {
            return res.status(404).json({ error: 'No timeline events found' });
        }

        const initialLength = timelineStore.events.length;
        timelineStore.events = timelineStore.events.filter(e => e.id !== event_id);
        
        if (timelineStore.events.length === initialLength) {
            return res.status(404).json({ error: 'Event not found' });
        }

        timelineStore.lastUpdated = new Date().toISOString();

        console.log(`🗑️ Timeline event deleted: ${event_id}`);

        res.json({ success: true, message: 'Event deleted' });
    } catch (error) {
        console.error('Timeline delete error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ NOTIFICATION MANAGEMENT ENDPOINTS ============

// GET notifications for user
app.get('/api/notifications', (req, res) => {
    try {
        const role = req.query.role; // 'student' or 'student-leader'
        const notifications = notificationStore.notifications || [];

        // Filter notifications based on role
        const filtered = role ? 
            notifications.filter(n => n.for_roles && n.for_roles.includes(role)) :
            notifications;

        res.json({ 
            success: true, 
            notifications: filtered,
            unread_count: filtered.filter(n => !n.read).length
        });
    } catch (error) {
        console.error('Notifications fetch error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// MARK notification as read
app.post('/api/notifications/:notification_id/read', (req, res) => {
    try {
        const { notification_id } = req.params;
        
        if (!notificationStore.notifications) {
            return res.status(404).json({ error: 'No notifications found' });
        }

        const notification = notificationStore.notifications.find(n => n.id === notification_id);
        if (!notification) {
            return res.status(404).json({ error: 'Notification not found' });
        }

        notification.read = true;

        console.log(`✅ Notification marked as read: ${notification_id}`);

        res.json({ success: true, notification: notification });
    } catch (error) {
        console.error('Mark read error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ GROUP DATA SYNC (for cross-device sharing) ============

// In-memory store for group data
const groupDataStore = {};

// POST - Save group data (members, etc)
app.post('/api/groups/data', (req, res) => {
    try {
        const { groupId, groupName, section, members } = req.body;
        
        if (!groupId || !groupName) {
            return res.status(400).json({ error: 'groupId and groupName are required' });
        }

        const key = `${section || 'default'}:${groupId}`;
        groupDataStore[key] = {
            groupId,
            groupName,
            section,
            members: members || [],
            updatedAt: new Date().toISOString()
        };

        console.log(`✅ Group data saved: ${key} - ${members?.length || 0} members`);
        console.log(`   Group members: ${JSON.stringify(members)}`);
        res.json({ success: true, key });
    } catch (error) {
        console.error('Group save error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// GET - Retrieve group data by ID
app.get('/api/groups/data/:groupId', (req, res) => {
    try {
        const { groupId } = req.params;
        const section = req.query.section || 'default';
        const key = `${section}:${groupId}`;
        
        let groupData = groupDataStore[key];
        
        // If not found with section, search all keys for this groupId
        if (!groupData) {
            console.log(`[/api/groups/data] Not found with section "${section}", searching all keys...`);
            for (let storeKey of Object.keys(groupDataStore)) {
                if (storeKey.endsWith(':' + groupId) || storeKey === groupId) {
                    groupData = groupDataStore[storeKey];
                    console.log(`[/api/groups/data] Found under key: ${storeKey}`);
                    break;
                }
            }
        }
        
        if (!groupData) {
            console.log(`[/api/groups/data] Group ${groupId} not found`);
            return res.json({ success: false, message: 'Group data not found' });
        }

        console.log(`[/api/groups/data] Returning ${groupData.members?.length || 0} members for group ${groupId}`);
        res.json({ success: true, data: groupData });
    } catch (error) {
        console.error('Group retrieve error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ DRAFT SUBMISSIONS SYNC (for cross-device sharing) ============

// In-memory store for draft submissions
const draftSubmissionsStore = [];

// POST - Save draft submission
app.post('/api/submissions/draft', (req, res) => {
    try {
        const draftSubmission = req.body;
        
        if (!draftSubmission.id) {
            draftSubmission.id = Date.now().toString();
        }
        if (!draftSubmission.submittedAt) {
            draftSubmission.submittedAt = new Date().toISOString();
        }

        draftSubmissionsStore.push(draftSubmission);
        
        console.log(`✅ Draft submission saved: ${draftSubmission.id} from ${draftSubmission.submittedBy} with ${draftSubmission.items?.length || 0} items`);
        console.log(`   Total submissions in store: ${draftSubmissionsStore.length}`);
        res.json({ success: true, submission: draftSubmission });
    } catch (error) {
        console.error('Draft submission save error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// GET - Retrieve all draft submissions
app.get('/api/submissions/draft', (req, res) => {
    try {
        const submittedBy = req.query.submittedBy;
        
        let submissions = draftSubmissionsStore;
        if (submittedBy) {
            submissions = submissions.filter(s => s.submittedBy === submittedBy);
        }
        
        if (submissions.length > 0) {
            console.log(`✅ [/api/submissions/draft] Retrieved ${submissions.length} submissions:`, submissions.map(s => `${s.submittedBy} (${s.items?.length || 0} items)`).join(', '));
        } else {
            console.log(`ℹ️ [/api/submissions/draft] No submissions found`);
        }
        res.json({ 
            success: true, 
            data: submissions,
            count: submissions.length
        });
    } catch (error) {
        console.error('Draft submission retrieve error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ WEBSOCKET SUPPORT (for real-time updates) ============

// Store WebSocket connections for different roles
const wsConnections = {
    'student': [],
    'student-leader': [],
    'adviser': []
};

// ============ RESEARCH PAPER SEARCH (for academic papers) ============

app.post('/api/search/papers', async (req, res) => {
    try {
        const { query, type } = req.body;

        if (!query) {
            return res.status(400).json({ error: 'Query is required' });
        }

        console.log(`Searching for ${type}: ${query}`);

        const promptText = `Search for recent academic papers about "${query}". 

Focus on finding 3-5 REAL published papers from:
- Google Scholar
- ResearchGate  
- PubMed
- Academic journals
- Conference proceedings

For each paper found, extract and provide:
1. Exact paper title
2. All authors (in "LastName, FirstInitial." format)
3. Publication year
4. Journal or conference name
5. A 2-3 sentence summary of the key findings
6. DOI or URL (if available)
7. Volume, issue, and page numbers (if available)

IMPORTANT: Only include papers that actually exist. Verify the information is real.

Return ONLY a JSON array in this exact format:
[
  {
    "title": "Exact paper title",
    "authors": "Author1, A., Author2, B., & Author3, C.",
    "year": "2024",
    "journal": "Journal Name",
    "summary": "Brief summary of findings and methodology",
    "doi": "https://doi.org/10.xxxx/xxxxx",
    "volume": "45",
    "issue": "3",
    "pages": "123-145"
  }
]

Only return the JSON array, nothing else.`;

        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${ANTHROPIC_API_KEY}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                contents: [
                    {
                        role: "user",
                        parts: [
                            {
                                text: promptText
                            }
                        ]
                    }
                ],
                generationConfig: {
                    maxOutputTokens: 4000,
                    temperature: 0.7
                }
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('Anthropic API Error:', errorText);
            throw new Error(`API request failed: ${response.status}`);
        }

        const data = await response.json();
        console.log('API Response received');

        let responseText = '';
        if (data.candidates && Array.isArray(data.candidates) && data.candidates.length > 0) {
            const candidate = data.candidates[0];
            if (candidate.content && candidate.content.parts && Array.isArray(candidate.content.parts)) {
                responseText = candidate.content.parts
                    .map(part => part.text)
                    .join('\n');
            }
        }

        let papers = [];
        try {
            const cleanText = responseText.replace(/```json\n?|\n?```/g, '').trim();
            papers = JSON.parse(cleanText);
        } catch (e) {
            console.error('Failed to parse JSON:', e);
            console.log('Raw response:', responseText);
            throw new Error('Unable to parse research results');
        }

        if (!Array.isArray(papers) || papers.length === 0) {
            throw new Error('No papers found in search results');
        }

        res.json({ success: true, papers });

    } catch (error) {
        console.error('Research error:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Serve static files AFTER all API routes (so API has priority)
const path = require('path');
const parentDir = path.join(__dirname, '..');
app.use(express.static(parentDir));

// Serve index.html for the root path
app.get('/', (req, res) => {
    res.sendFile(path.join(parentDir, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
    console.log(`📝 Open http://localhost:${PORT}/research-paper-editor.html in your browser`);
});