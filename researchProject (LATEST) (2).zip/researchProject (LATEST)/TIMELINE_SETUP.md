# Timeline Multi-Device Fix - Setup Instructions

## ✅ Server Status
- **Node Server**: Running on `http://localhost:3000` ✓
- **API Endpoints**: Working ✓
  - GET /api/timeline - Get all events
  - POST /api/timeline - Add new event
  - DELETE /api/timeline/:id - Delete event

## Setup Steps

### Step 1: Ensure Server is Running
The server is currently running. If you need to restart it:
```powershell
cd "c:\Users\Mama and others\researchProject (LATEST)\server"
npm start
```

### Step 2: Get the ngrok URL
The ngrok tunnel is running. To find your URL:

1. Open browser and go to: **http://127.0.0.1:4040**
2. Look for "Forwarding" section
3. You'll see: `https://xxx-yyy-zzz.ngrok-free.dev → http://localhost:3000`
4. **Copy the ngrok URL**: `https://xxx-yyy-zzz.ngrok-free.dev`

### Step 3: Test on Device B
On Device B (different device/browser), go to:
```
https://[your-ngrok-url]/timeline-test.html
```

You should see:
- ✅ "Current URL" = your ngrok URL
- ✅ "Base URL" = your ngrok URL  
- ✅ "API Endpoint" = your ngrok URL + /api/timeline
- ✅ Timeline events from server

### Step 4: Test Timeline Sync
1. **On Device A** (Adviser): Open `https://[ngrok-url]/Adviser_dashboard.html`
2. Add a timeline event
3. **On Device B** (Student): Open `https://[ngrok-url]/Student_dashboard.html`
4. Timeline event should appear immediately on badge
5. Click "Timeline" to see the full event

## Troubleshooting

**If you see "ERR_NGROK_8012":**
- Problem: Server on localhost:3000 not responding
- Solution: Check that `npm start` is running in the server folder
- Verify: Open http://localhost:3000/api/timeline - should return JSON

**If ngrok URL keeps changing:**
- This is normal with free ngrok accounts
- Check http://127.0.0.1:4040 for the current URL

**If timeline still doesn't sync:**
- Make sure Device B is accessing via ngrok URL, not localhost
- The fetch calls now use `window.location.origin` to detect the correct server URL
- Test on `https://[ngrok-url]/timeline-test.html` first

## Files Modified
✅ Student_dashboard.html - Updated fetch calls with baseUrl detection
✅ Student-leader.html - Updated fetch calls with baseUrl detection  
✅ Adviser_dashboard.html - Updated fetch calls with baseUrl detection
✅ server/index.js - Timeline API endpoints ready
✅ Created timeline-test.html - Diagnostic testing page
✅ Created START_SERVER.bat - One-click server startup script

## Quick Commands

**Kill all processes and restart:**
```powershell
Get-Process node, ngrok -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
cd "c:\Users\Mama and others\researchProject (LATEST)\server"
npm start
```

**Check server is running:**
```powershell
curl http://localhost:3000/api/timeline
```

**Check ngrok status:**
```
Open http://127.0.0.1:4040 in browser
```
