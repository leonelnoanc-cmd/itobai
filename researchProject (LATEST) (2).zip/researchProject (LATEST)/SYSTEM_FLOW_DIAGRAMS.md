# 📊 SYSTEM FLOW - VISUAL DIAGRAMS

## Complete System Architecture

```
╔════════════════════════════════════════════════════════════════════════════╗
║                    RESEARCH PAPER SUBMISSION SYSTEM                        ║
╚════════════════════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 1: CONTENT CREATION                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────┐                             │
│  │ research-paper-editor-leader.html         │                             │
│  ├──────────────────────────────────────────┤                             │
│  │ • Quill Rich Text Editor                 │                             │
│  │ • Add References                         │                             │
│  │ • Format Text (Bold, Italic, etc)        │                             │
│  │ • [Submit Paper] Button                  │                             │
│  └──────────┬───────────────────────────────┘                             │
│             │                                                               │
│             ├─> Save to:                                                   │
│             │   tempPaperContent = "<p>HTML...</p>"                        │
│             │   tempPaperReferences = "[...]"                             │
│             │                                                               │
│             └──> Redirect to: chapters-leader.html                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 2: CHAPTER SELECTION                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────┐                             │
│  │ chapters-leader.html                      │                             │
│  ├──────────────────────────────────────────┤                             │
│  │ ☐ Chapter 1                              │                             │
│  │   └─ Intro, Problem, Framework...        │                             │
│  │ ☐ Chapter 2                              │                             │
│  │   └─ Literature Review                   │                             │
│  │ ☑ Chapter 3                              │                             │
│  │   └─ Methodology                         │                             │
│  │ ☐ Chapter 4                              │                             │
│  │   └─ Results                             │                             │
│  │ ☐ Chapter 5                              │                             │
│  │   └─ Conclusions                         │                             │
│  │                                          │                             │
│  │ [Next] Button                            │                             │
│  └──────────┬───────────────────────────────┘                             │
│             │                                                               │
│             ├─> Build URL:                                                │
│             │   submission-leader.html?chapters=["3"]                     │
│             │                                                               │
│             └──> Pass to Phase 3                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 3: PART SELECTION & SUBMISSION                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────┐                             │
│  │ submission-leader.html                    │                             │
│  ├──────────────────────────────────────────┤                             │
│  │ CHAPTER 3: METHODOLOGY                   │                             │
│  │ ☐ Research Design                        │                             │
│  │ ☑ Locale of the Study                    │                             │
│  │ ☑ Research Instrument                    │                             │
│  │ ☐ Data Gathering Procedures              │                             │
│  │ ☐ Method of Data Analysis                │                             │
│  │                                          │                             │
│  │ [Send] Button                            │                             │
│  └──────────┬───────────────────────────────┘                             │
│             │                                                               │
│             ├─> Retrieve From localStorage:                               │
│             │   • tempPaperContent                                        │
│             │   • tempPaperReferences                                     │
│             │   • loggedInUser                                            │
│             │                                                               │
│             ├─> Create Submission Object:                                 │
│             │   {                                                         │
│             │     items: [                                                │
│             │       {                                                     │
│             │         chapter: "3",                                       │
│             │         part: "Locale of the Study",                        │
│             │         content: "..."                                      │
│             │       }                                                     │
│             │     ],                                                      │
│             │     submittedBy: "user123",                                 │
│             │     submittedAt: "2026-01-20T..."                           │
│             │   }                                                         │
│             │                                                               │
│             ├─> Save to localStorage.submissions                          │
│             │   Clear tempPaperContent                                    │
│             │   Clear tempPaperReferences                                 │
│             │                                                               │
│             └──> Redirect to: draft.html                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ PHASE 4: DRAFT ORGANIZATION & DISPLAY                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────┐                             │
│  │ draft.html                                │                             │
│  ├──────────────────────────────────────────┤                             │
│  │ 1. Read localStorage.submissions         │                             │
│  │ 2. Organize by chapter number (1-5)     │                             │
│  │ 3. Sort by predefined part order        │                             │
│  │ 4. Display organized paper              │                             │
│  └─────────────────────────────────────────┘                             │
│             │                                                               │
│             └──> FINAL OUTPUT:                                             │
│                                                                             │
│                  ┌─────────────────────────────────────┐                 │
│                  │ MY RESEARCH PAPER (ORGANIZED)       │                 │
│                  ├─────────────────────────────────────┤                 │
│                  │                                     │                 │
│                  │ CHAPTER 1: INTRODUCTION             │                 │
│                  │ Background of the Study             │                 │
│                  │ [Content here...]                   │                 │
│                  │                                     │                 │
│                  │ Statement of the Problem             │                 │
│                  │ [Content here...]                   │                 │
│                  │                                     │                 │
│                  │ CHAPTER 3: METHODOLOGY              │                 │
│                  │ Locale of the Study                 │                 │
│                  │ [Content here...]                   │                 │
│                  │                                     │                 │
│                  │ Research Instrument                 │                 │
│                  │ [Content here...]                   │                 │
│                  │                                     │                 │
│                  │ REFERENCES                          │                 │
│                  │ 1. Author, Year                     │                 │
│                  │ 2. Another Author, Year             │                 │
│                  │                                     │                 │
│                  └─────────────────────────────────────┘                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagram

```
                   ┌──────────────────────────┐
                   │   USER WRITES CONTENT    │
                   │ (Quill Editor)           │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ CLICK "SUBMIT PAPER"     │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────────────────┐
                   │ SAVE TO LOCALSTORAGE                 │
                   │ tempPaperContent = HTML              │
                   │ tempPaperReferences = Array          │
                   └───────────┬──────────────────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ REDIRECT TO CHAPTERS     │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ USER SELECTS CHAPTERS    │
                   │ (Checkboxes)             │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ CLICK "NEXT"             │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────────────────┐
                   │ BUILD URL WITH CHAPTERS PARAM        │
                   │ ?chapters=["1","2","3"]              │
                   └───────────┬──────────────────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ REDIRECT TO SUBMISSION   │
                   │ (Chapter parts page)     │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ USER SELECTS PARTS       │
                   │ (Checkboxes)             │
                   └───────────┬──────────────┘
                               │
                               ▼
                   ┌──────────────────────────┐
                   │ CLICK "SEND"             │
                   └───────────┬──────────────┘
                               │
                ┌──────────────┴──────────────┐
                │                             │
                ▼                             ▼
    ┌────────────────────────┐    ┌────────────────────────┐
    │ RETRIEVE FROM STORAGE: │    │ CREATE SUBMISSION OBJ: │
    │ • Content              │    │ • Chapter              │
    │ • References           │    │ • Part                 │
    │ • User Info            │    │ • Content              │
    └────────────┬───────────┘    │ • User                 │
                │                 │ • Timestamp            │
                └────────┬────────┘                        │
                         │                                 │
                         ▼                                 │
    ┌──────────────────────────────────────┐               │
    │ COMBINE DATA                         │◄──────────────┘
    │ item = {                             │
    │   chapter: string                    │
    │   part: string                       │
    │   content: string                    │
    │ }                                    │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ SAVE TO localStorage.submissions     │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ CLEAR TEMPORARY DATA                 │
    │ • tempPaperContent = DELETED         │
    │ • tempPaperReferences = DELETED      │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ REDIRECT TO DRAFT                    │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ DRAFT.HTML: READ SUBMISSIONS         │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ ORGANIZE BY CHAPTER (1→2→3→4→5)     │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ SORT BY PREDEFINED PART ORDER        │
    └────────────┬────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │ DISPLAY ORGANIZED PAPER              │
    │ Complete Research Document Ready     │
    └──────────────────────────────────────┘
```

---

## localStorage State Changes

```
┌─────────────────────────────────────────────────────────────────┐
│ BEFORE (Empty)                                                  │
├─────────────────────────────────────────────────────────────────┤
│ {                                                               │
│   "submissions": [],                                            │
│   "loggedInUser": { "username": "john_doe" },                  │
│   "userRole": "student-leader"                                 │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘

                    AFTER PHASE 1 (Write Content)
                               │
                               ▼

┌─────────────────────────────────────────────────────────────────┐
│ (Phase 1: Content saved)                                        │
├─────────────────────────────────────────────────────────────────┤
│ {                                                               │
│   "submissions": [],                                            │
│   "tempPaperContent": "<p>My research...</p>",                 │
│   "tempPaperReferences": "[\"Ref1\", \"Ref2\"]",               │
│   "loggedInUser": { "username": "john_doe" },                  │
│   "userRole": "student-leader"                                 │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘

                  AFTER PHASE 2 (Select Chapter)
                               │
                               ▼

┌─────────────────────────────────────────────────────────────────┐
│ (Phase 2: Chapter selected in URL)                              │
├─────────────────────────────────────────────────────────────────┤
│ {                                                               │
│   "submissions": [],                                            │
│   "tempPaperContent": "<p>My research...</p>",                 │
│   "tempPaperReferences": "[\"Ref1\", \"Ref2\"]",               │
│   "loggedInUser": { "username": "john_doe" },                  │
│   "userRole": "student-leader"                                 │
│ }                                                               │
│                                                                 │
│ URL: submission-leader.html?chapters=["1","3"]                │
└─────────────────────────────────────────────────────────────────┘

              AFTER PHASE 3 (Submit with Part Selected)
                               │
                               ▼

┌─────────────────────────────────────────────────────────────────┐
│ (Phase 3: Submission created and saved)                         │
├─────────────────────────────────────────────────────────────────┤
│ {                                                               │
│   "submissions": [                                              │
│     {                                                           │
│       "items": [                                                │
│         {                                                       │
│           "chapter": "1",                                       │
│           "part": "Background of the Study",                   │
│           "content": "<p>My research...</p>"                   │
│         }                                                       │
│       ],                                                        │
│       "submittedAt": "2026-01-20T10:30:00Z",                  │
│       "references": "[\"Ref1\", \"Ref2\"]",                    │
│       "submittedBy": "john_doe"                                │
│     }                                                           │
│   ],                                                            │
│   "loggedInUser": { "username": "john_doe" },                  │
│   "userRole": "student-leader"                                 │
│ }                                                               │
│                                                                 │
│ NOTE: tempPaperContent & tempPaperReferences DELETED ✓         │
└─────────────────────────────────────────────────────────────────┘

                AFTER PHASE 4 (View in Draft)
                               │
                               ▼

┌─────────────────────────────────────────────────────────────────┐
│ (Phase 4: Draft displays organized content)                     │
├─────────────────────────────────────────────────────────────────┤
│ DISPLAY:                                                        │
│                                                                 │
│ CHAPTER 1: INTRODUCTION                                         │
│ ─────────────────────────────────────────────                  │
│                                                                 │
│ Background of the Study                                         │
│ My research...                                                  │
│                                                                 │
│ REFERENCES                                                      │
│ ─────────────────────────────────────────────                  │
│ 1. Ref1                                                         │
│ 2. Ref2                                                         │
│                                                                 │
│ localStorage still contains:                                    │
│ - submissions array (persistence)                              │
│ - loggedInUser & userRole                                      │
└─────────────────────────────────────────────────────────────────┘
```

---

## Parallel vs Serial File Access

```
EDITOR FILE                 CHAPTER FILE              SUBMISSION FILE            DRAFT FILE
┌──────────────┐           ┌──────────────┐           ┌──────────────┐          ┌──────────────┐
│ Read: none   │           │ Read: URL    │           │ Read: URL    │          │ Read: local  │
│ Write: temp  │           │ Read: none   │           │ Read: temp   │          │ Read: user   │
│ localStorage │           │ Write: URL   │           │ Write: final │          │ Write: none  │
│              │           │              │           │ localStorage │          │              │
└──────────────┘           └──────────────┘           └──────────────┘          └──────────────┘
       │                           │                           │                        │
       │ REDIRECT                  │ REDIRECT                  │ REDIRECT               │
       └──────────────────────────>│                           │                        │
                                   │                           │                        │
                                   └──────────────────────────>│                        │
                                                               │                        │
                                                               └──────────────────────>│
                                                                                        │
                                                               FINAL OUTPUT             │
                                                               ORGANIZED PAPER ◄────────┘
```

---

## Chapter Structure Tree

```
CHAPTER 1: INTRODUCTION
├── Background of the Study
├── Statement of the Problem
├── Conceptual Framework
├── Theoretical Framework
├── Significance of the Study
├── Scope and Delimitation of the Study
└── Definition of Terms

CHAPTER 2: LITERATURE REVIEW
├── Review of Related Literature
└── Review of Related Studies

CHAPTER 3: METHODOLOGY
├── Research Design
├── Locale of the Study
├── Research Instrument
├── Data Gathering Procedures
└── Method of Data Analysis

CHAPTER 4: RESULTS
└── Presentation of Key Findings

CHAPTER 5: CONCLUSIONS
├── Summary
├── Implication of Findings
├── Conclusions
├── Recommendations
├── References
├── Appendices
└── Curriculum Vitae
```

---

## URL Parameter Flow

```
START
  │
  ▼
research-paper-editor-leader.html
  │ Click "Submit Paper"
  │
  ├─────────────────────────┐
  │ NO PARAMS              │
  │ Just save to temp      │
  │ and redirect           │
  │
  └──────────────────────┬─────────────────────┐
                         │                     │
                         ▼                     ▼
         chapters-leader.html          chapters.html
              (no params)             (no params)
              │ Click "Next"               │ Click "Next"
              │                           │
              ├──────┐           ┌────────┤
              │      │           │        │
              │  SELECT: ["1"]   │   SELECT: ["2","3"]
              │      │           │        │
              └──────┴──────┬────┴────────┘
                           │
         ?chapters=["1"] or ?chapters=["2","3"]
                           │
         ┌─────────────────┴──────────────────┐
         │                                    │
         ▼                                    ▼
submission-leader.html                submission.html
 /?chapters=["1"]                    /?chapters=["2","3"]
  │ Click "Send"                      │ Click "Send"
  │                                   │
  └──────────────────┬────────────────┘
                     │
                     │ NO PARAMS PASSED
                     │ (Data in localStorage)
                     │
                     ▼
              draft.html
              (no params)
              │
              └─> Read from localStorage.submissions
                  │
                  └─> Display organized
```

---

**This completes the visual documentation of the entire system flow!** 📊
