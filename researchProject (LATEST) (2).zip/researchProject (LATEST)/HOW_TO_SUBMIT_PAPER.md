# ⚠️ IMPORTANT: How to Submit Paper Correctly

## The Problem
You wrote content in research-paper-editor.html but it's not showing in revise-paper-student.html because **you didn't actually SUBMIT it**.

## The Complete Submission Flow (4 Steps)

### Step 1: Write in Research Paper Editor ✅ (You did this)
- Open: `research-paper-editor.html`
- Write your content (e.g., "b222222...")
- ✅ You're here

### Step 2: Submit the Paper ❌ (You need to do this)
- Click the **"Submit Paper"** button
- You should see alert: "Paper saved! Now select which chapter..."
- You will be redirected to **chapters.html**
- **If you don't see this, your content wasn't saved**

### Step 3: Select Chapter (in chapters.html)
- Click on a chapter (e.g., "Chapter 2")
- You will be redirected to **submission.html**

### Step 4: Select Parts and Send (in submission.html) ❌ (Critical!)
- You will see checkboxes for parts like:
  - "Review of Related Literature"
  - "Review of Related Studies"
  - etc.
- Check the boxes for which parts you want to submit
- Click the **"SEND"** button
- You should get alert: "✅ Submission sent successfully!"
- You will be redirected to **draft.html**

### Step 5: View in Revise Paper (adviser browser)
- Only THEN can the adviser see your new submission in **revise-paper-student.html**

## What You Did Wrong
- ✅ Wrote content in research-paper-editor.html
- ❌ Did NOT click "Submit Paper"
- ❌ Did NOT go through chapters.html
- ❌ Did NOT go through submission.html
- ❌ Did NOT select parts and click SEND

## What to Do Now

1. **Go back to research-paper-editor.html**
2. **Click "Submit Paper"** (your content `b222...` should still be there)
3. **Follow steps 3-5 above**
4. **Then check revise-paper-student.html** - you should see your `b222...` content

## Timing
Each step flows into the next:
```
research-paper-editor.html
    ↓ Click "Submit Paper"
chapters.html
    ↓ Click chapter
submission.html
    ↓ Check parts + Click "SEND"
draft.html
    ↓ Redirect
revise-paper-student.html (adviser sees it)
```

## If You Still See Old Content
The adviser might be looking at a **different part** of the paper. The URL shows what they're viewing:
```
?chapter=Chapter%202&part=Review%20of%20Related%20Studies
```

This means they're ONLY looking at "Review of Related Studies" from Chapter 2. If you submitted to a DIFFERENT part (e.g., "Presentation of Key Findings" in Chapter 4), they won't see it in this view.

**Make sure you:**
1. Submit to Chapter 2, Review of Related Studies specifically
2. Then the adviser will see your content in that exact part

## Console Logs to Check

After submitting, in submission.html console you should see:
```
[submission.html] New submission from: [Your Name]
[submission.html] New submission content length: 50+ (your b222... content)
[submission.html] New submission content preview: b222222...
```

If you see these logs, your submission worked! Then adviser should see your content.

