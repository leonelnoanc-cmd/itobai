# Quick Implementation Guide

## For Developers Working with These Files

---

## 1. Understanding the Improvements

Each file now includes:
- **Semantic HTML** tags (nav, main, aside, article, footer, header, section)
- **ARIA labels** for screen readers (aria-label, role, aria-live, etc.)
- **Meta tags** for SEO and browser integration
- **Mobile-responsive CSS** with media queries
- **Accessibility features** (focus indicators, keyboard support)

---

## 2. File-by-File Quick Reference

### revise-paper-student.html (Template for Others)
- **Best Example:** Yes - use as reference
- **Key Features:** Collaborative editing, adviser highlights, comprehensive CSS
- **What to Look For:** CSS organization, media queries, ARIA patterns

### research-paper-editor.html & research-paper-editor-leader.html
- **Key Features:** Reference panel, modal dialog, context menu
- **What to Look For:** Semantic reference panel, dialog element usage
- **Toolbar Pattern:** Look at editor-toolbar and button ARIA labels

### submitted-paper.html
- **Key Features:** Article viewing with comments
- **What to Look For:** Header/banner structure, live regions for comments
- **Pattern:** Article tag, aside for comments

### draft.html
- **Key Features:** Draft organization with chapters
- **What to Look For:** Main/article structure, status messages
- **Pattern:** Header, main, footer semantic structure

---

## 3. Common Patterns to Replicate

### Pattern 1: Navigation
```html
<nav class="nav-bar" role="navigation" aria-label="Main navigation">
    <button onclick="goBack()" aria-label="Go back to dashboard">← Back</button>
</nav>
```
**Use When:** You have a navigation section  
**Why:** Screen readers can identify and navigate to it  

---

### Pattern 2: Main Content
```html
<main class="editor-section" role="main">
    <h1>Page Title</h1>
    <article>Content</article>
</main>
```
**Use When:** You have main page content  
**Why:** Only one `<main>` per page, proper landmark  

---

### Pattern 3: Sidebar
```html
<aside class="sidebar" role="complementary" aria-label="Related information">
    Content
</aside>
```
**Use When:** You have complementary content  
**Why:** Designates secondary content clearly  

---

### Pattern 4: Toolbar
```html
<div id="toolbar" role="toolbar" aria-label="Text formatting toolbar">
    <button aria-label="Bold">B</button>
    <button aria-label="Italic">I</button>
</div>
```
**Use When:** You have formatting controls  
**Why:** Screen readers announce it as a toolbar  

---

### Pattern 5: Modal Dialog
```html
<dialog id="modal" aria-label="Confirm action">
    <header>
        <h2>Are you sure?</h2>
        <button aria-label="Close">×</button>
    </header>
    <section>Content</section>
</dialog>
```
**Use When:** You have modal/popup dialogs  
**Why:** Semantic `<dialog>` element with proper structure  

---

### Pattern 6: Live Region
```html
<div id="status" aria-live="polite" aria-label="Status message">
    Ready
</div>
```
**Use When:** Content updates dynamically  
**Why:** Screen readers announce updates automatically  

---

### Pattern 7: Form Control
```html
<label for="email">Email:</label>
<input id="email" type="email" 
       aria-label="Email address" required>
```
**Use When:** You have form inputs  
**Why:** Proper label association and accessibility  

---

## 4. Accessibility Checklist

Before deploying ANY new HTML:

### HTML Structure
- [ ] Use `<h1>` for main page title
- [ ] Use semantic tags (nav, main, aside, article, footer, header)
- [ ] Only one `<main>` per page
- [ ] Proper heading hierarchy (h1 → h2 → h3, no skipping)

### ARIA & Labels
- [ ] All buttons have `aria-label` or visible text
- [ ] Links describe where they go
- [ ] Form inputs have associated `<label>` elements
- [ ] Dynamic content has `aria-live` regions
- [ ] Modal dialogs use `<dialog>` element

### Keyboard Navigation
- [ ] Tab key works through all controls
- [ ] Enter/Space activates buttons
- [ ] Focus indicators are visible (not outline: none!)
- [ ] Tooltips work with keyboard

### Visual Design
- [ ] Text color contrast ≥ 4.5:1 for body text
- [ ] Color is not the only way to convey info
- [ ] Hover effects work with keyboard focus
- [ ] Text resizes properly at 200% zoom

### Responsive
- [ ] Viewport meta tag present
- [ ] Layout works at 480px width
- [ ] Touch targets ≥ 44x44 pixels
- [ ] No horizontal scroll on mobile

---

## 5. CSS Snippets to Reuse

### Focus Indicator
```css
button:focus-visible {
    outline: 2px solid var(--primary-color);
    outline-offset: 2px;
}
```

### Responsive Container
```css
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

@media (max-width: 768px) {
    .container {
        padding: 15px;
    }
}
```

### Touch-Friendly Button
```css
button {
    padding: 12px 24px;
    min-height: 44px;
    min-width: 44px;
}
```

### Reduced Motion
```css
@media (prefers-reduced-motion: reduce) {
    * {
        animation-duration: 0.01ms !important;
        transition-duration: 0.01ms !important;
    }
}
```

---

## 6. JavaScript Best Practices

### Managing Focus
```javascript
// When opening a modal, move focus there
const modal = document.getElementById('modal');
modal.focus();

// When closing, restore focus to button
const triggerButton = document.activeElement;
modal.addEventListener('close', () => {
    triggerButton.focus();
});
```

### Updating Live Regions
```javascript
// Update status (screen readers will announce)
const status = document.getElementById('status');
status.textContent = 'File saved successfully';
// No need to alert() - screen reader will read this
```

### Keyboard Events
```javascript
button.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        button.click();
    }
});
```

### Handling ARIA Attributes
```javascript
// Update aria-expanded when toggling
const button = document.getElementById('toggle');
const content = document.getElementById('content');

button.addEventListener('click', () => {
    const isExpanded = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', !isExpanded);
    content.hidden = !content.hidden;
});
```

---

## 7. Testing Your Changes

### Quick Accessibility Check
1. **Keyboard:** Can you navigate using Tab key?
2. **Focus:** Are focus indicators visible?
3. **Colors:** Are text colors contrasty enough?
4. **Text:** Is page readable at 200% zoom?
5. **Mobile:** Does it work on small screens?

### Tools to Use
- **Keyboard:** Just Tab through your page
- **Screen Reader:** 
  - Windows: NVDA (free)
  - Mac: VoiceOver (built-in)
  - Browser: VoiceOver (Safari)
- **Color Contrast:** WebAIM Color Contrast Checker
- **Automated:** Lighthouse, WAVE, axe DevTools

### Browser DevTools
```
Chrome: Ctrl+Shift+I → Lighthouse → Accessibility
Firefox: F12 → Accessibility → Activate
```

---

## 8. Common Mistakes to Avoid

❌ **DON'T:**
```html
<!-- ❌ Removing focus indicators -->
button:focus { outline: none; }

<!-- ❌ Vague button text -->
<button>Click here</button>

<!-- ❌ Skipping heading levels -->
<h1>Title</h1>
<h3>Content</h3>  <!-- Should be h2! -->

<!-- ❌ Using color only for information -->
<p style="color: red">Error</p>  <!-- Add icon or text too -->

<!-- ❌ Inline event handlers (deprecated) -->
<button onclick="save()">Save</button>

<!-- ❌ Removing semantic meaning -->
<div role="button" onclick="...">Not a button</div>
```

✅ **DO:**
```html
<!-- ✅ Clear focus indicators -->
button:focus-visible {
    outline: 2px solid blue;
}

<!-- ✅ Descriptive button text -->
<button aria-label="Save document">💾 Save</button>

<!-- ✅ Proper heading hierarchy -->
<h1>Title</h1>
<h2>Content</h2>

<!-- ✅ Text AND visual indicators -->
<p>❌ <span style="color: red">Error</span></p>

<!-- ✅ Event listeners in JavaScript -->
button.addEventListener('click', save);

<!-- ✅ Real button element -->
<button type="button">Click me</button>
```

---

## 9. Migration Guide

### Updating an Old File

1. **Add Meta Tags to `<head>`:**
```html
<meta name="description" content="...">
<meta name="theme-color" content="#007bff">
```

2. **Update Body Structure:**
```html
<!-- OLD -->
<div class="nav-bar">...</div>
<div class="content">...</div>

<!-- NEW -->
<nav role="navigation">...</nav>
<main role="main">...</main>
```

3. **Add ARIA Labels:**
```html
<!-- OLD -->
<button onclick="save()">💾</button>

<!-- NEW -->
<button onclick="save()" aria-label="Save document">💾</button>
```

4. **Check Headings:**
```html
<!-- OLD -->
<h2>Page Title</h2>

<!-- NEW -->
<h1>Page Title</h1>
```

5. **Add Focus Styles:**
```css
button:focus-visible {
    outline: 2px solid var(--primary-color);
    outline-offset: 2px;
}
```

---

## 10. Quick Reference Card

### Semantic Tags
| Tag | Use | ARIA Role |
|-----|-----|-----------|
| `<nav>` | Navigation | navigation |
| `<main>` | Main content | main |
| `<header>` | Top section | banner |
| `<footer>` | Bottom section | contentinfo |
| `<aside>` | Side content | complementary |
| `<article>` | Complete content | article |
| `<section>` | Content grouping | region |
| `<h1>-<h6>` | Headings | heading |

### ARIA Essentials
| Attribute | When to Use | Example |
|-----------|------------|---------|
| `aria-label` | Button with icon | `<button aria-label="Close">×</button>` |
| `aria-live` | Dynamic updates | `<div aria-live="polite">Updated</div>` |
| `role="..."` | Semantic meaning | `<div role="navigation">` |
| `aria-expanded` | Toggles | `<button aria-expanded="false">` |
| `aria-controls` | Related content | `<button aria-controls="menu">` |

---

## 11. Getting Help

### Documentation
- **Detailed Summary:** HTML_IMPROVEMENTS_SUMMARY.md
- **Developer Guide:** ACCESSIBILITY_STANDARDS.md
- **Reference Implementation:** revise-paper-student.html

### External Resources
- MDN Web Accessibility: https://developer.mozilla.org/en-US/docs/Web/Accessibility
- ARIA Practices: https://www.w3.org/WAI/ARIA/apg/
- WCAG Guidelines: https://www.w3.org/WAI/WCAG21/quickref/

### Testing Tools
- WAVE: https://wave.webaim.org/
- axe DevTools: https://www.deque.com/axe/devtools/
- Lighthouse: Built into Chrome DevTools
- WebAIM Contrast: https://webaim.org/resources/contrastchecker/

---

## 12. Summary

✅ **You now have:**
- 6 improved HTML files with best practices
- Comprehensive documentation
- Code examples and patterns
- Testing guidelines
- Common patterns to reuse

✅ **These files are:**
- Accessible (WCAG 2.1 AA)
- Mobile-responsive
- Well-organized
- Secure
- SEO-optimized
- Keyboard-navigable
- Screen-reader friendly

✅ **Ready for:**
- Production deployment
- Further enhancement
- Team collaboration
- Accessibility audits

---

**Keep improving the web! Make it accessible for everyone.** ♿ 🌍

*Last Updated: 2024*
