# Code Changes Reference

## File 1: revise-paper-student.html

### Change 1: Updated `saveRevision()` Function

**Location:** Lines 931-991

**What Changed:**
- Extract chapter and part from URL parameters
- Save to `revisedSubmissions` instead of `submissions`
- Create adviser notification
- Auto-redirect to `paper-comparison.html`

**Before:**
```javascript
alert('✓ Revisions saved successfully!\n\nYour updated work has been submitted for adviser review.');
goBack();
```

**After:**
```javascript
// Get chapter and part from URL params
const params = new URLSearchParams(window.location.search);
const chapter = params.get('chapter') || 'Unknown Chapter';
const part = params.get('part') || 'Unknown Part';

// Store revised submission
const revisionRecord = {
    chapter: chapter,
    part: part,
    revisedContent: revisedContent,
    revisedAt: new Date().toISOString(),
    revisedBy: currentSubmitter || 'Anonymous Student',
    groupMembers: groupMembers,
    feedbackReference: feedbackComments,
    isGroupRevision: groupMembers.length > 1
};

// Store in revised submissions
let revisedSubmissions = JSON.parse(localStorage.getItem('revisedSubmissions') || '{}');
const key = `${chapter}_${part}`;
if (!revisedSubmissions[key]) {
    revisedSubmissions[key] = [];
}
revisedSubmissions[key].push(revisionRecord);
localStorage.setItem('revisedSubmissions', JSON.stringify(revisedSubmissions));

// Create adviser notification
let adviserNotifications = JSON.parse(localStorage.getItem('adviserRevisionNotifications') || '[]');
adviserNotifications.push({
    id: Date.now().toString(),
    chapter: chapter,
    part: part,
    revisedBy: currentSubmitter,
    revisedAt: new Date().toISOString(),
    status: 'new',
    message: `Revision submitted for ${chapter} - ${part}`
});
localStorage.setItem('adviserRevisionNotifications', JSON.stringify(adviserNotifications));

alert('✓ Revisions saved successfully!\n\nYour updated work has been submitted for adviser review.');

// Redirect to paper-comparison to show adviser the changes
window.location.href = `paper-comparison.html?chapter=${encodeURIComponent(chapter)}&part=${encodeURIComponent(part)}`;
```

---

### Change 2: Updated `goBack()` Function

**Location:** Lines 993-1004

**What Changed:**
- Added role check for adviser
- Route advisers to `group-dashboard.html`

**Before:**
```javascript
function goBack() {
    clearInterval(syncInterval);
    const userRole = localStorage.getItem('userRole');
    if (userRole === 'student-leader' || userRole === 'leader') {
        window.location.href = 'Student-leader.html';
    } else {
        window.location.href = 'Student_dashboard.html';
    }
}
```

**After:**
```javascript
function goBack() {
    clearInterval(syncInterval);
    const userRole = localStorage.getItem('userRole');
    
    // If adviser viewing revisions, go back to group-dashboard
    if (userRole === 'adviser') {
        window.location.href = 'group-dashboard.html';
    } else if (userRole === 'student-leader' || userRole === 'leader') {
        window.location.href = 'Student-leader.html';
    } else {
        window.location.href = 'Student_dashboard.html';
    }
}
```

---

## File 2: paper-comparison.html

### Change 1: Updated `loadContent()` Function

**Location:** Lines 769-809

**What Changed:**
- Separate original and revised content display
- Original on left panel, revised on right panel
- Each panel gets appropriate content

**Before:**
```javascript
// Display content on both sides
if (typeof contentToDisplay === 'string') {
    leftPanel.innerHTML = contentToDisplay;
    rightPanel.innerHTML = contentToDisplay;
}
```

**After:**
```javascript
// Display original on left panel
if (originalContent) {
    if (typeof originalContent === 'string') {
        leftPanel.innerHTML = originalContent;
    } else if (typeof originalContent === 'object' && originalContent.content) {
        leftPanel.innerHTML = originalContent.content;
    } else {
        leftPanel.innerHTML = originalContent;
    }
} else {
    leftPanel.innerHTML = '<div class="no-content-message">📄 No original submission found</div>';
}

// Display revised on right panel
if (revisedContent) {
    if (typeof revisedContent === 'string') {
        rightPanel.innerHTML = revisedContent;
    } else if (typeof revisedContent === 'object' && revisedContent.revisedContent) {
        rightPanel.innerHTML = revisedContent.revisedContent;
    } else {
        rightPanel.innerHTML = revisedContent;
    }
    console.log('✓ Revised content loaded');
} else {
    rightPanel.innerHTML = '<div class="no-content-message">📝 No revision submitted yet</div>';
}
```

---

### Change 2: New Function `getRevisedContentNew()`

**Location:** Lines 813-837

**What Changed:**
- New function specifically for retrieving revised submissions
- Pulls from `revisedSubmissions` localStorage
- Returns latest revision if multiple exist

**Added:**
```javascript
function getRevisedContentNew() {
    try {
        // Check revisedSubmissions storage
        const revisedSubmissions = JSON.parse(localStorage.getItem('revisedSubmissions') || '{}');
        const key = `${currentChapter}_${currentPart}`;
        
        if (revisedSubmissions[key] && Array.isArray(revisedSubmissions[key])) {
            // Get the most recent revision
            const revisions = revisedSubmissions[key];
            const latest = revisions[revisions.length - 1];
            console.log('✓ Found revised submission:', latest);
            return latest;
        }
    } catch (e) {
        console.error('Error fetching revised content:', e);
    }
    return null;
}
```

---

### Change 3: Updated loadContent() to use new function

**Location:** Line 778

**Added:**
```javascript
// Get revised content
const revisedContent = getRevisedContentNew();
```

---

## File 3: group-dashboard.html

### Change: Updated `openPaperViewer()` Function

**Location:** Lines 1661-1726

**What Changed:**
- Added role check at start of function
- If adviser: redirect to `revise-paper-student.html`
- If student with 'revise' status: redirect to `paper-comparison.html`

**Before (First Lines):**
```javascript
function openPaperViewer(chapter, part) {
    try {
        const status = getPartStatus(chapter, part);
        
        // If status is 'revise', redirect to paper comparison page
        if (status === 'revise') {
            window.location.href = `paper-comparison.html?chapter=${encodeURIComponent(chapter)}&part=${encodeURIComponent(part)}`;
            return;
        }
```

**After (First Lines):**
```javascript
function openPaperViewer(chapter, part) {
    try {
        const userRole = localStorage.getItem('userRole');
        const status = getPartStatus(chapter, part);
        
        // If adviser clicks on a part, navigate to revise-paper-student.html to allow revisions
        if (userRole === 'adviser') {
            window.location.href = `revise-paper-student.html?chapter=${encodeURIComponent(chapter)}&part=${encodeURIComponent(part)}`;
            return;
        }
        
        // If status is 'revise', redirect to paper comparison page
        if (status === 'revise') {
            window.location.href = `paper-comparison.html?chapter=${encodeURIComponent(chapter)}&part=${encodeURIComponent(part)}`;
            return;
        }
```

---

## Data Structure Changes

### New: localStorage.revisedSubmissions

```javascript
{
  "Chapter 1_Background of the Study": [
    {
      "chapter": "Chapter 1",
      "part": "Background of the Study",
      "revisedContent": "<p>Updated background content...</p>",
      "revisedAt": "2026-01-25T10:30:00.000Z",
      "revisedBy": "John Doe",
      "groupMembers": ["John Doe"],
      "feedbackReference": [],
      "isGroupRevision": false
    }
  ],
  "Chapter 2_Review of Related Literature": [
    {
      "chapter": "Chapter 2",
      "part": "Review of Related Literature",
      "revisedContent": "<p>First revision...</p>",
      "revisedAt": "2026-01-25T14:15:00.000Z",
      "revisedBy": "Jane Smith",
      "groupMembers": ["Jane Smith", "Alex Johnson"],
      "feedbackReference": [],
      "isGroupRevision": true
    },
    {
      "chapter": "Chapter 2",
      "part": "Review of Related Literature",
      "revisedContent": "<p>Second revision...</p>",
      "revisedAt": "2026-01-25T16:45:00.000Z",
      "revisedBy": "Jane Smith",
      "groupMembers": ["Jane Smith", "Alex Johnson"],
      "feedbackReference": [],
      "isGroupRevision": true
    }
  ]
}
```

### New: localStorage.adviserRevisionNotifications

```javascript
[
  {
    "id": "1705925400000",
    "chapter": "Chapter 2",
    "part": "Review of Related Literature",
    "revisedBy": "John Doe",
    "revisedAt": "2026-01-25T10:30:00.000Z",
    "status": "new",
    "message": "Revision submitted for Chapter 2 - Review of Related Literature"
  },
  {
    "id": "1705927800000",
    "chapter": "Chapter 3",
    "part": "Research Design",
    "revisedBy": "Jane Smith",
    "revisedAt": "2026-01-25T11:45:00.000Z",
    "status": "new",
    "message": "Revision submitted for Chapter 3 - Research Design"
  }
]
```

---

## URL Parameter Usage

### Pattern:
```
?chapter=[Chapter Name]&part=[Part Name]
```

### Examples:
```
revise-paper-student.html?chapter=Chapter%202&part=Review%20of%20Related%20Literature
paper-comparison.html?chapter=Chapter%201&part=Background%20of%20the%20Study
```

### How Parameters are Used:
```javascript
// Parse parameters
const params = new URLSearchParams(window.location.search);
const chapter = params.get('chapter');
const part = params.get('part');

// Use in navigation
window.location.href = `paper-comparison.html?chapter=${encodeURIComponent(chapter)}&part=${encodeURIComponent(part)}`;
```

---

## Key Implementation Details

### 1. Chapter and Part Extraction
- Each page uses `new URLSearchParams(window.location.search)` to get params
- Parameters are URL-encoded with `encodeURIComponent()`
- Fallback values provided if params missing

### 2. Revision Storage Strategy
- Revisions stored in object with "Chapter_Part" keys
- Each key maps to array of revisions (supports multiple)
- Latest revision retrieved by accessing `array[array.length - 1]`

### 3. Role-Based Navigation
- `userRole` retrieved from `localStorage.getItem('userRole')`
- Checked at start of `openPaperViewer()` in group-dashboard
- Routes adviser to `revise-paper-student.html` instead of modal

### 4. Automatic Notification
- Notifications created in `adviserRevisionNotifications` array
- Each notification has unique `id` (timestamp)
- Status starts as 'new', can be updated later

---

**Implementation Status:** ✅ Complete  
**All Changes:** Integrated & Verified  
**Ready for:** Testing & Deployment
