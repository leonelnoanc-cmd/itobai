# Data Isolation Fix - Multi-User Account Separation

## Problem
When multiple user accounts (Account A and Account B) were created with different roles (e.g., adviser), the data stored in localStorage was shared between accounts. This meant:
- When Account A (adviser) added sections, groups, and timelines
- Account B (another adviser) could see all the same data

## Root Cause
All data was being stored in localStorage using static, non-user-specific keys:
- `advisorSections`
- `allSectionGroups`
- `researchTimeline`
- `timelineSections`
- `currentSection`
- `currentGroup`
- etc.

Since localStorage is per-browser/domain, there was no user-specific scoping.

## Solution Implemented
Implemented user-specific localStorage keys by appending each user's email/username to every localStorage key.

### Helper Function
Added a `getUserKey()` function to all dashboard files that:
1. Retrieves the logged-in user from `localStorage.getItem('loggedInUser')`
2. Extracts the user's email or username as a unique identifier
3. Appends this identifier to all localStorage keys with underscore: `${baseKey}_${userId}`

Example:
```javascript
function getUserKey(baseKey) {
    if (!CURRENT_USER_ID) {
        const loggedInUser = localStorage.getItem('loggedInUser');
        if (loggedInUser) {
            try {
                const user = JSON.parse(loggedInUser);
                CURRENT_USER_ID = user.email || user.username || 'default-user';
            } catch (e) {
                CURRENT_USER_ID = loggedInUser;
            }
        }
    }
    return `${baseKey}_${CURRENT_USER_ID}`;
}
```

### Files Modified

#### 1. **Adviser_dashboard.html**
- Added `getUserKey()` helper function
- Updated all localStorage operations:
  - `advisorSections` → `advisorSections_${userId}`
  - `adviserNotifications` → `adviserNotifications_${userId}`
  - `researchTimeline` → `researchTimeline_${userId}`
  - `timelineSections` → `timelineSections_${userId}`
  - `allSectionGroups` → `allSectionGroups_${userId}`

#### 2. **Student_dashboard.html**
- Added `getUserKey()` helper function
- Updated all localStorage operations:
  - `currentSection` → `currentSection_${userId}`
  - `currentGroup` → `currentGroup_${userId}`
  - `timelineSections` → `timelineSections_${userId}`
  - `researchTimeline` → `researchTimeline_${userId}`
  - `allSectionGroups` → `allSectionGroups_${userId}`

#### 3. **Student-leader.html**
- Added `getUserKey()` helper function at global scope
- Updated all localStorage operations for user-specific keys

#### 4. **section-groups.html**
- Added `getUserKey()` helper function
- Updated:
  - `currentSection` → `currentSection_${userId}`
  - `allSectionGroups` → `allSectionGroups_${userId}`

#### 5. **group-dashboard.html**
- Added `getUserKey()` helper function
- Updated:
  - `currentGroup` → `currentGroup_${userId}`
  - `currentGroupId` → `currentGroupId_${userId}`
  - `currentSection` → `currentSection_${userId}`
  - `allSectionGroups` → `allSectionGroups_${userId}`
  - `timelineSections` → `timelineSections_${userId}`

#### 6. **research-group.html**
- Added `getUserKey()` helper function
- Updated:
  - `currentSection` → `currentSection_${userId}`
  - `allSectionGroups` → `allSectionGroups_${userId}`

#### 7. **draft.html**
- Added `getUserKey()` helper function
- Updated:
  - `adviserNotifications` → `adviserNotifications_${userId}`
  - `adviserDraftSubmissions` → `adviserDraftSubmissions_${userId}`
  - `memberScores` → `memberScores_${userId}`
  - `currentSection` → `currentSection_${userId}`
  - `currentGroup` → `currentGroup_${userId}`
  - `allSectionGroups` → `allSectionGroups_${userId}`

### Logout Cleanup
Enhanced logout functions in multiple files to clear both user-specific and non-specific keys for backwards compatibility:
```javascript
const accountScopedKeys = [
    'advisorSections',
    'researchTimeline',
    'allSectionGroups',
    // ... etc
];

accountScopedKeys.forEach(key => {
    localStorage.removeItem(getUserKey(key));  // User-specific version
    localStorage.removeItem(key);               // Non-specific version (fallback)
});
```

## Testing the Fix

### Test Scenario
1. **Account A Setup:**
   - Create new account with adviser role
   - Add 3 sections
   - Add 2 groups to first section
   - Add 3 timeline events

2. **Account B Verification:**
   - Log out from Account A
   - Create new account with different email
   - Verify NO sections appear
   - Verify NO groups appear
   - Verify NO timeline events appear
   - Add new sections/groups/timelines

3. **Account A Re-verification:**
   - Log back into Account A
   - Verify original sections/groups/timelines are still there
   - Verify Account B's data is NOT visible

### Browser Developer Tools Check
```javascript
// In browser console, check localStorage:
// For Account A (user@example.com):
- advisorSections_user@example.com
- allSectionGroups_user@example.com
- researchTimeline_user@example.com

// For Account B (user2@example.com):
- advisorSections_user2@example.com
- allSectionGroups_user2@example.com
- researchTimeline_user2@example.com
```

## Backwards Compatibility
The logout function removes both user-specific and non-specific keys to ensure clean separation and handle any legacy data. This means users who previously had shared data will have it cleared on next logout.

## Additional Notes
- The fix maintains the existing authentication flow (login/signup)
- No changes to server-side code required
- All existing functionality preserved
- Data isolation now complete at the browser level
