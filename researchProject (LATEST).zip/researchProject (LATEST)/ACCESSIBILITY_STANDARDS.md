# Accessibility & Code Standards

## Quick Reference for Developers

This document outlines the accessibility and HTML standards implemented across the research project. Follow these patterns when creating or modifying HTML files.

---

## 1. Semantic HTML Structure

### Navigation
```html
<nav class="nav-bar" role="navigation" aria-label="Main navigation">
    <button onclick="goBack()" aria-label="Go back to dashboard">← Back</button>
</nav>
```

### Main Content
```html
<main class="editor-section" role="main">
    <h1>Page Title</h1>
    <article>Content here</article>
</main>
```

### Sidebars & Complementary Content
```html
<aside class="sidebar" role="complementary" aria-label="Related information">
    Content here
</aside>
```

### Headers & Footers
```html
<header class="header" role="banner">
    <h1>Site Title</h1>
</header>

<footer class="footer" role="contentinfo">
    Footer content
</footer>
```

### Forms
```html
<section class="form-group" role="region">
    <label for="inputId">Input Label:</label>
    <input id="inputId" type="text" aria-label="Input description">
</section>
```

---

## 2. ARIA Labels & Roles

### Button Labels
```html
<!-- ✅ GOOD: Descriptive label -->
<button aria-label="Save document">💾 Save</button>

<!-- ✅ GOOD: Keyboard shortcut in title -->
<button title="Save (Ctrl+S)" aria-label="Save document">💾 Save</button>

<!-- ❌ BAD: No label -->
<button>💾</button>
```

### Live Regions (for dynamic updates)
```html
<!-- For status updates -->
<div id="status" aria-live="polite" aria-label="Status message">
    Ready
</div>

<!-- For important alerts -->
<div id="alert" aria-live="assertive" role="alert">
    Error message
</div>
```

### Textbox (Editor)
```html
<div id="editor" 
     role="textbox" 
     aria-label="Content editor"
     aria-multiline="true">
</div>
```

### Toolbar
```html
<div class="toolbar" role="toolbar" aria-label="Text formatting toolbar">
    <button class="ql-bold" aria-label="Bold"></button>
    <button class="ql-italic" aria-label="Italic"></button>
</div>
```

### Menu
```html
<nav role="menu" aria-label="Context menu">
    <button role="menuitem" onclick="option1()">Option 1</button>
    <button role="menuitem" onclick="option2()">Option 2</button>
</nav>
```

### Dialog/Modal
```html
<dialog aria-label="Confirm action" role="alertdialog">
    <header>
        <h2>Confirm</h2>
        <button aria-label="Close dialog">×</button>
    </header>
    <section>Content</section>
</dialog>
```

---

## 3. Heading Hierarchy

```html
<!-- ✅ GOOD: Proper hierarchy -->
<h1>Main Page Title</h1>
<section>
    <h2>Section Title</h2>
    <article>
        <h3>Article Title</h3>
    </article>
</section>

<!-- ❌ BAD: Skipping levels -->
<h1>Title</h1>
<h3>Skipped h2!</h3>
```

---

## 4. Form Accessibility

```html
<!-- ✅ GOOD: Proper label association -->
<label for="email">Email Address:</label>
<input id="email" type="email" aria-label="Email address" required>

<!-- ✅ GOOD: Fieldset for grouping -->
<fieldset>
    <legend>Choose an option</legend>
    <input type="radio" id="opt1" name="options">
    <label for="opt1">Option 1</label>
</fieldset>

<!-- ❌ BAD: Floating placeholder as label -->
<input type="email" placeholder="Email">
```

---

## 5. Focus Management

```css
/* ✅ GOOD: Clear focus indicator */
button:focus-visible {
    outline: 2px solid var(--primary-color);
    outline-offset: 2px;
}

/* ✅ GOOD: Keyboard only focus */
.element:focus-visible {
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.5);
}

/* ❌ BAD: Removing focus entirely */
button:focus {
    outline: none;
}
```

---

## 6. Color & Contrast

```css
/* ✅ GOOD: Sufficient contrast (WCAG AA) */
.text {
    color: #212529;  /* Dark text */
    background: #ffffff;  /* White background */
    /* Ratio: 18.4:1 */
}

/* ✅ GOOD: Use CSS variables for consistency */
:root {
    --primary-color: #007bff;
    --text-color: #212529;
}
```

**Minimum Contrast Ratios:**
- Normal text: 4.5:1
- Large text (18pt+): 3:1
- UI components: 3:1

---

## 7. Images & Icons

```html
<!-- ✅ GOOD: Descriptive alt text for images -->
<img src="chart.png" alt="Sales chart showing Q1-Q4 revenue trends">

<!-- ✅ GOOD: Empty alt for decorative images -->
<img src="decoration.png" alt="">

<!-- ✅ GOOD: ARIA label for icon buttons -->
<button aria-label="Download file" title="Download (Ctrl+D)">
    📥 Download
</button>

<!-- ❌ BAD: No alternative text -->
<img src="chart.png">

<!-- ❌ BAD: Redundant text -->
<img src="logo.png" alt="Logo image">
```

---

## 8. Links

```html
<!-- ✅ GOOD: Descriptive link text -->
<a href="/docs/guide.pdf">Read the user guide</a>

<!-- ✅ GOOD: External links clearly marked -->
<a href="https://example.com" title="Opens in new window" target="_blank">
    External Link
</a>

<!-- ❌ BAD: Vague link text -->
<a href="/docs/guide.pdf">Click here</a>

<!-- ❌ BAD: No indication of new window -->
<a href="https://example.com" target="_blank">Link</a>
```

---

## 9. Keyboard Accessibility

### Keyboard Shortcuts in Button Titles
```html
<button title="Bold (Ctrl+B)" aria-label="Bold text">B</button>
<button title="Save (Ctrl+S)" aria-label="Save document">💾</button>
```

### Tab Order (Usually automatic)
```html
<!-- Elements are tabbed in document order -->
<button>First</button>  <!-- Tab 1 -->
<input>  <!-- Tab 2 -->
<a href="#">Link</a>  <!-- Tab 3 -->

<!-- Override if needed (use sparingly) -->
<button tabindex="1">Second</button>
<button tabindex="2">First</button>

<!-- Remove from tab order (use cautiously) -->
<div tabindex="-1">Not focusable</div>
```

---

## 10. Meta Tags Template

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- SEO & Accessibility -->
    <meta name="description" content="Brief page description (155 characters max)">
    <meta name="theme-color" content="#007bff">
    
    <!-- Title -->
    <title>Page Title - Site Name</title>
    
    <!-- Resources -->
    <link rel="stylesheet" href="style.css">
    <script src="script.js" crossorigin="anonymous"></script>
</head>
```

---

## 11. CSS Organization

```css
/* ===== CSS Variables & Root Styles ===== */
:root {
    --primary-color: #007bff;
    --secondary-color: #6c757d;
    --transition: all 0.3s ease;
}

/* ===== Global Styles ===== */
* { }
html { }
body { }

/* ===== Main Sections ===== */
.nav-bar { }
main { }
.sidebar { }
footer { }

/* ===== Components ===== */
.button { }
.form-group { }

/* ===== Responsive Design ===== */
@media (max-width: 768px) {
    /* Mobile styles */
}

/* ===== Accessibility ===== */
@media (prefers-reduced-motion: reduce) {
    * {
        animation-duration: 0.01ms !important;
    }
}

/* ===== Print Styles ===== */
@media print {
    /* Print-specific styles */
}
```

---

## 12. JavaScript Best Practices for Accessibility

### Managing Focus
```javascript
// Move focus to newly opened modal
const modal = document.getElementById('modal');
modal.focus();

// Restore focus when closing modal
const triggerButton = document.activeElement;
modal.addEventListener('close', () => {
    triggerButton.focus();
});
```

### Announcing Updates
```javascript
// Update live region for screen readers
const status = document.getElementById('status');
status.textContent = 'Update completed successfully';
// Screen readers will announce this automatically
```

### Keyboard Events
```javascript
// Handle Enter key on buttons
button.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        button.click();
    }
});
```

---

## 13. Testing Checklist

### Manual Testing
- [ ] All functionality works with keyboard (Tab, Enter, Space, Arrow keys)
- [ ] All interactive elements are clearly focused
- [ ] Color is not the only way to convey information
- [ ] Text has sufficient contrast ratio (4.5:1)
- [ ] Page is readable at 200% zoom
- [ ] All buttons have descriptive labels or ARIA labels

### Automated Testing
- [ ] WAVE Accessibility Checker (wave.webaim.org)
- [ ] axe DevTools browser extension
- [ ] Lighthouse Accessibility Audit
- [ ] NVDA or JAWS screen reader

### Mobile Testing
- [ ] Touch targets are at least 44x44 pixels
- [ ] Page reflows properly on small screens
- [ ] Orientation changes are handled
- [ ] Mobile screen readers work (VoiceOver, TalkBack)

---

## 14. Common Patterns

### Button Group
```html
<div class="button-group" role="group" aria-label="Actions">
    <button aria-label="Save">💾 Save</button>
    <button aria-label="Delete">🗑️ Delete</button>
    <button aria-label="Share">📤 Share</button>
</div>
```

### Expandable Section
```html
<button aria-expanded="false" aria-controls="details">
    Show More
</button>
<section id="details" hidden>
    Hidden content
</section>

<script>
button.addEventListener('click', () => {
    const isExpanded = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', !isExpanded);
    details.hidden = !details.hidden;
});
</script>
```

### Skip to Main Content
```html
<a href="#main-content" class="skip-link">Skip to main content</a>

<nav>Navigation here</nav>

<main id="main-content">
    Main content here
</main>

<style>
.skip-link {
    position: absolute;
    top: -40px;
    left: 0;
    z-index: 100;
}

.skip-link:focus {
    top: 0;
}
</style>
```

---

## 15. Resources

- [W3C WAI Web Accessibility Guidelines](https://www.w3.org/WAI/)
- [MDN Web Accessibility](https://developer.mozilla.org/en-US/docs/Web/Accessibility)
- [ARIA Authoring Practices Guide](https://www.w3.org/WAI/ARIA/apg/)
- [WebAIM Color Contrast Checker](https://webaim.org/resources/contrastchecker/)

---

## Summary

✅ **Always Remember:**
1. Use semantic HTML first
2. Add ARIA only when needed
3. Test with keyboard navigation
4. Test with screen readers
5. Check color contrast
6. Ensure proper focus management
7. Keep mobile users in mind

---

**Last Updated:** 2024  
**Status:** Active Standards Document
